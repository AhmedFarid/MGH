Resolving dependencies for Checkout App
=======================================

1. Add cardIO libraries in ExternalComponents folder

2. Add MCCMerchant.framework in ExternalComponents folder

3. Resolve Carthage dependencies

   Run the following command in the project directory:

   carthage update --platform ios

