//
//  MerchantCheckoutAppUITests.swift
//  MerchantCheckoutAppUITests
//
//  Created by MasterCard on 9/25/17.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest
@testable import MerchantCheckoutApp
class MerchantCheckoutAppUITests: XCTestCase {
    let app = XCUIApplication()
    
    override func setUp() {
        super.setUp()
        
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        XCUIApplication().launch()
        sleep(3)
        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testCartScreen() {
        
        // Tap on Card button as no product exist
        self.cartButtonTapped()
        
        // Tap on items and add product in cart
        self.addProductsToCart(_count: 4)
        
        // Enter in confirm Product screen
                self.cartWithProductButtonTapped()
        
        // Remove all the product from Cart
        self.removeProductFromCart(_count: 5)
        
        // Tap on items and add product in cart
        self.addProductsToCart(_count: 5)
        
        // Cart Button Tapped with products
        self.cartWithProductButtonTapped()
        
        // Increase product count
        self.increaseCountofProduct(_index: 2, ofProduct: 2)
        
        // Decrease product count
        self.decreaseCountofProduct(_index: 2, ofProduct: 2)
        
        // Checkout for payment button Tapped
        self.checkoutForPaymentButtonTapped()
        
        //Wait to load masterpass login screen
        sleep(10)
        
        self.masterPassLogin()
        
        //        self.masterPassButtonTapped()
        
        //        self.masterpassUserIdTextField()
        self.backButtonTapped()
        
        //        self.rightMenuButtonTapped()
        
    }
    
    //MARK:- Cart to checkout Product
    
    func cartButtonTapped () {
        let cartWithoutProductButton = app.buttons["cartButton"]
        
        if cartWithoutProductButton.exists {
            cartWithoutProductButton.tap()
        }
    }
    
    func addProductsToCart (_count:Int) {
        for  i in 0..<_count {
            let productCell = app.collectionViews.cells.children(matching:.any).element(boundBy: i)
            if productCell.exists{
                productCell.buttons["addToCart"].tap()
            }
        }
    }
    
    func cartWithProductButtonTapped () {
        let cartButtonWithProduct = app.buttons["cartWithProductsButton"]
        if cartButtonWithProduct.exists {
            cartButtonWithProduct.tap()
        }
    }
    
    func removeProductFromCart(_count:Int) {
        for  i in (0..<_count).reversed()  {
            let removeProductButton = app.scrollViews.otherElements.tables.cells.element(boundBy: i).buttons["removeProduct"]
            if removeProductButton .exists {
                removeProductButton.tap()
            }
        }
    }
    
    func increaseCountofProduct(_index:Int, ofProduct product:Int) {
        let moreProductAddButton = app.scrollViews.otherElements.tables.cells.element(boundBy: product).children(matching:.any).element(boundBy: 2)
        if moreProductAddButton .exists {
            moreProductAddButton.tap()
        }
    }
    
    func decreaseCountofProduct(_index:Int, ofProduct product:Int) {
        let moreProductAddButton = app.scrollViews.otherElements.tables.cells.element(boundBy: product).children(matching:.any).element(boundBy: 1)
        if moreProductAddButton .exists {
            moreProductAddButton.tap()
        }
    }
    
    func checkoutForPaymentButtonTapped () {
        let checkoutButton = app.buttons["MasterpassButton"]
        if checkoutButton.exists {
            XCTAssertTrue(checkoutButton.exists, "Checkout button Tapped for products payment")
            checkoutButton.tap()
        }
    }
    
    //MARK:- Settings
    func settingButtonTapped () {
        // Card Selection View
        
        self.settingsSelectionOption(_count: 5, selectedOption: 0)
        self.backButtonTapped()
        
        //Language selection View
        self.settingsSelectionOption(_count: 2, selectedOption: 1)
        self.backButtonTapped()
        
        // Currency Selection View
        self.settingsSelectionOption(_count: 4, selectedOption: 2)
        self.backButtonTapped()
        
        //   self.settingsSelectionOption(_count: 0, selectedOption: 4)
        
        //Enable express checkout
        let  selectdSettingOption = app.tables.cells.element(boundBy: 5)
        if selectdSettingOption.exists {
            selectdSettingOption.tap()
        }
        //  self.settingsSelectionOption(_count: 0, selectedOption: 5)
        sleep(5)
        
        self .loginButtonTapped()
        //        self.masterPassButtonTapped()
        //
        sleep(2)
        //DSRP Description
        self.settingsSelectionOption(_count: 2, selectedOption: 6)
        //        self.settingsSelectionOption(_count: 2, selectedOption: 6)
        //
        //        // Handle login flow
        //
        //
        //        self.backButtonTapped()
        //
        //        self.backButtonTapped()
    }
    
    func enableAndDisableSupressShippingButton () {
        
    }
    
    func enableAndDisableExpressCheckoutButton () {
        
    }
    //MARK:- Back Button
    
    func backButtonTapped()   {
        if  app.buttons["backImage"].exists {
            app.buttons["backImage"].tap()
        }
    }
    
    func testRightMenuButtonTapped () {
        
        self .menuButtonTapped()
        
        self.rightMenuSettingsButtonTapped()
        
        self.settingButtonTapped()
        
        self .menuButtonTapped()
        
        self.rightMenuProfileButtonTapped()
        
        self .logoutButtonTapped()
        
        self .loginButtonTapped()
        
    }
    
    func menuButtonTapped () {
        let menuButton = app.buttons["menuButton"]
        if menuButton.exists {
            menuButton.tap()
        }
    }
    
    func rightMenuSettingsButtonTapped () {
        let rightMenuSettingsButton = app.buttons["settingsButton"]
        if rightMenuSettingsButton.exists {
            rightMenuSettingsButton.tap()
        }
    }
    
    func rightMenuProfileButtonTapped () {
        let rightMenuProfileButtonTapped = app.buttons["loginButton"]
        if rightMenuProfileButtonTapped.exists {
            rightMenuProfileButtonTapped.tap()
        }
    }
    
    func settingsSelectionOption (_count:Int, selectedOption _option:Int ) {
        let  selectdSettingOption = app.tables.cells.element(boundBy: _option)
        if selectdSettingOption.exists {
            selectdSettingOption.tap()
            for  i in 0..<_count {
                let cardItem = app.tables.cells.element(boundBy: i)
                if cardItem.exists {
                    cardItem.tap()
                }
            }
            app.tables.cells.element(boundBy: 0).tap()
        }
    }
    //MARK:- Login and Logout Methods
    
    func loginButtonTapped () {
        
        let usernameTextField = app.textFields["U S E R N A M E"]
        if usernameTextField.exists {
            usernameTextField.tap()
            usernameTextField.typeText("jsmith")
        }
        let passwordTextField = app.secureTextFields["P A S S W O R D"]
        if usernameTextField.exists {
            passwordTextField.tap()
            passwordTextField.typeText("password")
        }
        if app.buttons["Login"].exists {
            app.buttons["Login"].tap()
        }
        
    }
    func logoutButtonTapped () {
        let logoutAlert = app.alerts["You are already logged in"]
        if logoutAlert.exists {
            logoutAlert.buttons["Logout"].tap()
            sleep(3)
        }
    }
    
    
    
    // MARK:- App to web checkout
    func masterPassButtonTapped () {
        let webViewsQuery = app.webViews
        let masterPassOptionButton = webViewsQuery.buttons["masterpass"]
        if masterPassOptionButton.exists {
            masterPassOptionButton.tap()
            self.masterPassLogin()
            // self.masterpassUserIdTextField()
        }
        
        //        let paylibprodOptionButton = webViewsQuery.buttons["Paylibprod"]
        //        if paylibprodOptionButton.exists {
        //            paylibprodOptionButton.tap()
        //        }
        //        let paylibOptionButton = webViewsQuery.buttons["Paylib"]
        //        if paylibOptionButton.exists {
        //            paylibOptionButton.tap()
        //        }
        
        
    }
    
    
    func masterpassUserIdTextField () {
        let webViewsQuery = app.webViews
        let usernameTextField =   webViewsQuery.textFields["Email or Mobile Number"]
        if usernameTextField.exists {
            usernameTextField.tap()
            usernameTextField.typeText("shubhi.g@moofwd.com")
        }
        let passwordTextField = webViewsQuery.secureTextFields["Password"]
        if passwordTextField.exists {
            passwordTextField.tap()
            passwordTextField.typeText("Moofwd@123")
        }
        let signInButton = webViewsQuery.buttons["Sign In"]
        if signInButton.exists {
            signInButton.tap()
        }
        
    }
    
    func masterPassLogin() {
        let webViewsQuery = app.webViews
        let passwordSecureTextField = webViewsQuery/*@START_MENU_TOKEN@*/.secureTextFields["Password"]/*[[".otherElements.matching(identifier: \"main\").secureTextFields[\"Password\"]",".secureTextFields[\"Password\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        
        if passwordSecureTextField.exists {
            
            passwordSecureTextField.tap()
            passwordSecureTextField.typeText("moofwd@123")
        }
        
        let signInButton = webViewsQuery.buttons["Sign In"]
        if signInButton.exists {
            signInButton.tap()
        }
        sleep(15)
    }
    
    
    //MARK:- Confirmation after payment flow
    
    func continueButtonTapped () {
        let webViewsQuery = XCUIApplication().webViews
        let continueButton = webViewsQuery/*@START_MENU_TOKEN@*/.buttons["Continue"]/*[[".otherElements.matching(identifier: \"main\").buttons[\"Continue\"]",".buttons[\"Continue\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        if continueButton.exists {
            continueButton.tap()
        }
    }
    
    func confirmOrderButtonTapped () {
        let iConfirmButton = app.buttons["I CONFIRM"]
        if iConfirmButton.exists {
            iConfirmButton.tap()
        }
        sleep(5)
        
        self.continueShoppingButtonTapped()
        sleep(10)
        
    }
    
    func continueShoppingButtonTapped () {
        let continueShoppingButton = app.buttons["Continue Shopping"]
        if continueShoppingButton.exists {
            continueShoppingButton.tap()
        }
    }
    
    func testWebtoAppCheckoutPayment () {
        
        //        self.menuButtonTapped()
        //        self.rightMenuProfileButtonTapped()
        //        self.logoutButtonTapped()
        //        sleep(5)
        self.addProductsToCart(_count: 2)
        self.cartWithProductButtonTapped()
        self.checkoutForPaymentButtonTapped()
        sleep(10)
        self.masterPassLogin()
        sleep(10)
        self.continueButtonTapped()
        sleep(10)
        self.confirmOrderButtonTapped ()
        sleep(10)
        self.continueShoppingButtonTapped()
        sleep(10)
        
    }
    
    func testExpressCheckoutWithSupressShippingFirstTime () {
        
        self.menuButtonTapped()
        self.rightMenuSettingsButtonTapped()
        
        let tablesQuery = app.tables
        let supressShippingSwitchValue = tablesQuery/*@START_MENU_TOKEN@*/.switches["SUPRESS SHIPPING"]/*[[".cells.switches[\"SUPRESS SHIPPING\"]",".switches[\"SUPRESS SHIPPING\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.value as! String
        if supressShippingSwitchValue != "1" {
            tablesQuery/*@START_MENU_TOKEN@*/.switches["SUPRESS SHIPPING"]/*[[".cells.switches[\"SUPRESS SHIPPING\"]",".switches[\"SUPRESS SHIPPING\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        }
  
        
        
        let enableExpressCheckoutValue = tablesQuery/*@START_MENU_TOKEN@*/.switches["ENABLE EXPRESS CHECKOUT"]/*[[".cells.switches[\"ENABLE EXPRESS CHECKOUT\"]",".switches[\"ENABLE EXPRESS CHECKOUT\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.value as!String
        if enableExpressCheckoutValue != "1" {
            tablesQuery/*@START_MENU_TOKEN@*/.switches["ENABLE EXPRESS CHECKOUT"]/*[[".cells.switches[\"ENABLE EXPRESS CHECKOUT\"]",".switches[\"ENABLE EXPRESS CHECKOUT\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        }
        
        sleep(2)
        //Enable expresscheckout
        
        //        self.settingsSelectionOption(_count: 0, selectedOption: 5)
        self.loginButtonTapped()
        sleep(4)
        self.backButtonTapped()
        self.addProductsToCart(_count: 2)
        self.cartWithProductButtonTapped()
        self.checkoutWithExpressButtonTapped()
        sleep(10)
        self.masterPassLogin()
        sleep(10)
        self.enableAndContinueButtonTapped()
        
        sleep(10)
        self.confirmOrderButtonTapped ()
        sleep(10)
        self.continueShoppingButtonTapped()
        sleep(10)
        
        
    }
    func testCheckoutWithoutShippingAddress () {
        
        
        //        let tablesQuery = app.tables
        //        let supressShippingSwitch = tablesQuery/*@START_MENU_TOKEN@*/.switches["SUPRESS SHIPPING"]/*[[".cells.switches[\"SUPRESS SHIPPING\"]",".switches[\"SUPRESS SHIPPING\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        //     let switchValue =   supressShippingSwitch.valueIndicators
        //        supressShippingSwitch.tap()
        //        tablesQuery/*@START_MENU_TOKEN@*/.switches["ENABLE EXPRESS CHECKOUT"]/*[[".cells.switches[\"ENABLE EXPRESS CHECKOUT\"]",".switches[\"ENABLE EXPRESS CHECKOUT\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        //        supressShippingSwitch.tap()
        
        self.menuButtonTapped()
        self.rightMenuSettingsButtonTapped()
        
        let tablesQuery = app.tables
        //        let switchValue =   supressShippingSwitch.isSelected
        
        let supressShippingSwitchValue = tablesQuery/*@START_MENU_TOKEN@*/.switches["SUPRESS SHIPPING"]/*[[".cells.switches[\"SUPRESS SHIPPING\"]",".switches[\"SUPRESS SHIPPING\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.value as! String
        if supressShippingSwitchValue != "1" {
            tablesQuery/*@START_MENU_TOKEN@*/.switches["SUPRESS SHIPPING"]/*[[".cells.switches[\"SUPRESS SHIPPING\"]",".switches[\"SUPRESS SHIPPING\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        }
        
        //        self.settingsSelectionOption(_count: 0, selectedOption: 4)
        
        
        let enableExpressCheckoutValue = tablesQuery/*@START_MENU_TOKEN@*/.switches["ENABLE EXPRESS CHECKOUT"]/*[[".cells.switches[\"ENABLE EXPRESS CHECKOUT\"]",".switches[\"ENABLE EXPRESS CHECKOUT\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.value as!String
        if enableExpressCheckoutValue != "1" {
            tablesQuery/*@START_MENU_TOKEN@*/.switches["ENABLE EXPRESS CHECKOUT"]/*[[".cells.switches[\"ENABLE EXPRESS CHECKOUT\"]",".switches[\"ENABLE EXPRESS CHECKOUT\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        }
        
        sleep(2)
        //Enable expresscheckout
 
        self.loginButtonTapped()
        sleep(4)
        self.backButtonTapped()
        self.addProductsToCart(_count: 2)
        self.cartWithProductButtonTapped()
        //self.checkoutForPaymentButtonTapped()
        self.checkoutWithExpressButtonTapped()
        //        sleep(10)
        //        self.masterPassLogin()
        sleep(10)
        // self.enableAndContinueButtonTapped()
        self.checkoutExpressWithExpressButtonTapped()
        
        sleep(10)
        self.confirmOrderButtonTapped ()
        sleep(10)
        self.continueShoppingButtonTapped()
        sleep(10)
        
        
    }
    
    func checkoutWithExpressButtonTapped () {
        let checkoutButton = app.buttons["CHECKOUT"]
        if checkoutButton.exists {
            XCTAssertTrue(checkoutButton.exists, "Checkout button Tapped for products payment")
            checkoutButton.tap()
        }
    }
    
    func checkoutExpressWithExpressButtonTapped () {
        let checkoutButton = app.buttons["EXPRESS CHECKOUT"]
        if checkoutButton.exists {
            XCTAssertTrue(checkoutButton.exists, "Checkout button Tapped for products payment")
            checkoutButton.tap()
        }
    }
    
    
    func enableAndContinueButtonTapped () {
        let webViewsQuery = XCUIApplication().webViews
        let continueButton = webViewsQuery.buttons["Enable & Continue"]
        if continueButton.exists {
            continueButton.tap()
        }
    }
    
    
    func testPaymentMethods () {
        
        self.menuButtonTapped()
        
        self.rightMenuSettingsButtonTapped()
        
        self.settingsSelectionOption(_count: 0, selectedOption: 7)
        
        sleep(15)
        
        self.masterPassLogin()
        
        sleep(10)
        self.paymentEnableButton()
        
        sleep(4)
        
        self.backButtonTapped()

    }
    
    func paymentEnableButton () {
        let webViewsQuery = XCUIApplication().webViews
        let continueButton = webViewsQuery.buttons["Enable"]
        if continueButton.exists {
            continueButton.tap()
        }
    }
}
