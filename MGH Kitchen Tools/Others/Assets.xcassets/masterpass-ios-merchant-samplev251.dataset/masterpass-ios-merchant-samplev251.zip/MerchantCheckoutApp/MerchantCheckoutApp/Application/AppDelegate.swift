//
//  AppDelegate.swift
//  Merchant Checkout App
//
//  Created by MasterCard on 9/25/17.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import UIKit
import MCCMerchant
import NVActivityIndicatorView
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    /// Window instance, used by the navigation helper
    var window: UIWindow?
    
    // MARK: Methods
    
    ///  Override point for customization after application launch.
    ///
    /// - Parameters:
    ///   - application:
    ///   - launchOptions:
    /// - Returns:
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        NVActivityIndicatorView.DEFAULT_TYPE = .ballClipRotatePulse
        NVActivityIndicatorView.DEFAULT_COLOR = UIColor(red:247, green: 158, blue: 27)
        NVActivityIndicatorView.DEFAULT_BLOCKER_MINIMUM_DISPLAY_TIME = 1000
        ProductListWireFrame.presentProductListModule(fromView: self)
        
        return true
    }
    
    
    /// Handles the URL if the apps is awake from a URL Scheme
    ///
    /// - Parameters:
    ///   - application: 
    ///   - url:
    ///   - sourceApplication:
    ///   - annotation:
    /// - Returns:
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        if MCCMerchant.handleMasterpassResponse(url.absoluteString, delegate: MasterpassSDKManager.sharedInstance) {
            //TODO:Remove below comment when checkoutdata service is working
            //CallbackResponseHandlerManager.handle(checkoutResponse: CheckoutResponse.sharedInstance, withSDKManager: MasterpassSDKManager.sharedInstance)
        }
        return true
    }
    
    
}

