# GenerateManifest

Put cardIO libraries into this folder.

libCardIO.a
libopencv_core.a
libopencv_imgproc.a

Put MCCMerchant.framework into this folder.
