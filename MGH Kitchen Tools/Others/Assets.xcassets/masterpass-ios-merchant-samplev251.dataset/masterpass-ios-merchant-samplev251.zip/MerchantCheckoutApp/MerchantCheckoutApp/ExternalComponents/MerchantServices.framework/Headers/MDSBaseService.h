//
//  MDSBaseService.h
//  MerchantServices
//
//  Created by Patel, Utkal on 4/10/18.
//  Copyright © 2018 Patel, Utkal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MDSOAuthProvider.h"
#import "MDSNetworkManager.h"

@interface MDSBaseService : NSObject

@end
