//
//  Product.swift
//  MerchantApp
//
//  Created by Sebastian Jorquera on 09/26/2017.
//  Copyright © 2017 MooFWD. All rights reserved.
//

import Foundation

struct Product {
    var productId: String
    var name: String
    var price: Double
    var salePrice: Double
    var image: String
    var description: String
    var dateAdded: String
}
