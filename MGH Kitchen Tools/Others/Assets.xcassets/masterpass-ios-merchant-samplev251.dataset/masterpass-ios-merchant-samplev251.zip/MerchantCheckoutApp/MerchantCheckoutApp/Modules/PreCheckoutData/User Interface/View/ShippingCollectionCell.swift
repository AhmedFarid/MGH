//
//  ShippingCollectionCell.swift
//  MerchantCheckoutApp
//
//  Created by MasterCard on 11/9/17.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import Foundation
/// Cell used in the collection view to show the shipping addresses
class ShippingCollectionCell: UICollectionViewCell {
    @IBOutlet weak var shippingAddressLabel: UILabel!
    
}
