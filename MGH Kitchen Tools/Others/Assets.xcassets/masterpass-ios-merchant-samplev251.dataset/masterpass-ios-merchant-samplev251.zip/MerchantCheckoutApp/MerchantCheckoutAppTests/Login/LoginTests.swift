//
//  LoginInteractorTests.swift
//  MerchantCheckoutApp
//
//  Created by MasterCard on 11/01/2017.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest
@testable import MerchantCheckoutApp
class LoginTests: XCTestCase {

    var view: LoginViewProtocol!
    var presenter: LoginPresenterProtocol!
    var interactor: LoginInteractorInputProtocol!
    var APIDataManager: LoginAPIDataManagerInputProtocol!
    var localDataManager: LoginLocalDataManagerInputProtocol!
    var wireFrame: LoginWireFrameProtocol!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        self.view = LoginViewController.instantiate()
        self.presenter = LoginPresenter()
        self.interactor = LoginInteractor(isEnablingExpressCheckout: false)
        self.APIDataManager = LoginAPIDataManager()
        self.localDataManager = LoginLocalDataManager()
        self.wireFrame = LoginWireFrame()
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testLogin(){
        let expec = XCTestExpectation(description: "Do Login!")
        self.APIDataManager.doLogin(username: "jsmith", password: "password"){ responseObject, error in
            let status: String = responseObject?.value(forKey: "status") as! String
            if status == Constants.status.OK{
                expec.fulfill()
            }
        }
        wait(for: [expec], timeout: 10.0)
    }
}
