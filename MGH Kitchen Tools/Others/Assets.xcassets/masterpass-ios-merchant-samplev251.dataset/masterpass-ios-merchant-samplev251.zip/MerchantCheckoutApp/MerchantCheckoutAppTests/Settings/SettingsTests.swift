//
//  SettingsInteractorTests.swift
//  MerchantCheckoutApp
//
//  Created by MasterCard on 09/26/2017.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest
@testable import MerchantCheckoutApp
class SettingsTests: XCTestCase {

    var view: SettingsViewProtocol!
    var presenter: SettingsPresenterProtocol!
    var interactor: SettingsInteractorInputProtocol!
    var APIDataManager: SettingsAPIDataManagerInputProtocol!
    var localDataManager: SettingsLocalDataManagerInputProtocol!
    var wireFrame: SettingsWireFrameProtocol!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        self.view = SettingsViewController.instantiate()
        self.presenter  = SettingsPresenter()
        self.interactor  = SettingsInteractor()
        self.APIDataManager  = SettingsAPIDataManager()
        self.localDataManager  = SettingsLocalDataManager()
        self.wireFrame  = SettingsWireFrame()
    }
    
    func testSuppressShipping(){
        let initialSuppress: Bool = SDKConfiguration.sharedInstance.suppressShipping
        SDKConfiguration.sharedInstance.suppressShipping = !initialSuppress
        XCTAssertTrue(SDKConfiguration.sharedInstance.suppressShipping != initialSuppress, "The suppress shipping value has not been saved properly")
    }
}
