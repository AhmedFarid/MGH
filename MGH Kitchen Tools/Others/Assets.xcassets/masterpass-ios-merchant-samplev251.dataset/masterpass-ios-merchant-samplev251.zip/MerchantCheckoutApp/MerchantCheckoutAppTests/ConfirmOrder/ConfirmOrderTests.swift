//
//  ConfirmOrderInteractorTests.swift
//  MerchantCheckoutApp
//
//  Created by MasterCard on 10/08/2017.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest

@testable import MerchantCheckoutApp
class ConfirmOrderTests: XCTestCase {

    // Generating module components
    var view: ConfirmOrderViewProtocol!
    var presenter: ConfirmOrderPresenterProtocol!
    var interactor: ConfirmOrderInteractorInputProtocol!
    var APIDataManager: ConfirmOrderAPIDataManagerInputProtocol!
    var localDataManager: ConfirmOrderLocalDataManagerInputProtocol!
    var wireFrame: ConfirmOrderWireFrameProtocol!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        // Generating module components
        self.view = ConfirmOrderViewController.instantiate() as! ConfirmOrderViewProtocol
        self.presenter  = ConfirmOrderPresenter()
        self.interactor = ConfirmOrderInteractor(withPaymentData: nil)
        self.APIDataManager = ConfirmOrderAPIDataManager()
        self.localDataManager = ConfirmOrderLocalDataManager()
        self.wireFrame = ConfirmOrderWireFrame()
    }
    
    func testGetPaymentData(){
        let checkoutResponse: CheckoutResponse = CheckoutResponse.sharedInstance
        checkoutResponse.cartId = "123123"
        checkoutResponse.checkoutResourceURL = "dummyURL"
        checkoutResponse.transactionId = "321321"
        checkoutResponse.isError = false
        
        let expec = XCTestExpectation(description: "Get Payment Data!")
        self.APIDataManager?.getPaymentData(){ responseObject, error in
            let status: String = responseObject?.value(forKey: "status") as! String
            if status == Constants.status.OK {
                expec.fulfill()
            }
        }
        wait(for: [expec], timeout: 10.0)
    }
    
    
    func testPostback(){
        let checkoutResponse: CheckoutResponse = CheckoutResponse.sharedInstance
        checkoutResponse.cartId = "123123"
        checkoutResponse.checkoutResourceURL = "dummyURL"
        checkoutResponse.transactionId = "321321"
        checkoutResponse.isError = false
        
        let expec = XCTestExpectation(description: "Do Postback!")
        self.APIDataManager?.confirmOrder(){ responseObject, error in
            let status: String = responseObject?.value(forKey: "status") as! String
            if status == Constants.status.OK{
                expec.fulfill()
            }
        }
        wait(for: [expec], timeout: 10.0)
    }
}
