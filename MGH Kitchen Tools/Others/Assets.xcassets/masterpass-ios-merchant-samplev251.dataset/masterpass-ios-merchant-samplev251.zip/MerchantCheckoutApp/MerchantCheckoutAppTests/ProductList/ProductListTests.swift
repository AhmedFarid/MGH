//
//  ProductListInteractorTests.swift
//  MerchantCheckoutApp
//
//  Created by MasterCard on 09/26/2017.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest

@testable import MerchantCheckoutApp
class ProductListTests: XCTestCase {

    // Generating module components
    var view: ProductListViewProtocol!
    var presenter: ProductListPresenterProtocol!
    var interactor: ProductListInteractorInputProtocol!
    var APIDataManager: ProductListAPIDataManagerInputProtocol!
    var localDataManager: ProductListLocalDataManagerInputProtocol!
    var wireFrame: ProductListWireFrameProtocol!
    
    override func setUp() {
        super.setUp()
        // Generating module components
        self.view = ProductListViewController.instantiate()
        self.presenter = ProductListPresenter()
        self.interactor = ProductListInteractor()
        self.APIDataManager = ProductListAPIDataManager()
        self.localDataManager = ProductListLocalDataManager()
        self.wireFrame = ProductListWireFrame()
    }

    func testGetProducts(){
        
        let expec = XCTestExpectation(description: "Get Products!")
        
        self.APIDataManager?.fetchProductsFromServer(){ responseObject, error in
            let status: String = responseObject?.value(forKey: "status") as! String
            if status == Constants.status.OK{
                expec.fulfill()
            }
        }
        wait(for: [expec], timeout: 10.0)
    }
}
