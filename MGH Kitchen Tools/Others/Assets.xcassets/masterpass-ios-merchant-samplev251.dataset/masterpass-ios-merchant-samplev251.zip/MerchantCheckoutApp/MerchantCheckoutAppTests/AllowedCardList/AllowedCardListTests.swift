//
//  AllowedCardListInteractorTests.swift
//  MerchantCheckoutApp
//
//  Created by MasterCard on 10/16/2017.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest
@testable import MerchantCheckoutApp
class AllowedCardListTests: XCTestCase {

    var view: AllowedCardListViewProtocol!
    var presenter: AllowedCardListPresenterProtocol!
    var interactor: AllowedCardListInteractorInputProtocol!
    var APIDataManager: AllowedCardListAPIDataManagerInputProtocol!
    var localDataManager: AllowedCardListLocalDataManagerInputProtocol!
    var wireFrame: AllowedCardListWireFrameProtocol!
    
    override func setUp() {
        super.setUp()
        // Generating module components
        self.view = AllowedCardListViewController.instantiate()
        self.presenter = AllowedCardListPresenter()
        self.interactor = AllowedCardListInteractor()
        self.APIDataManager = AllowedCardListAPIDataManager()
        self.localDataManager = AllowedCardListLocalDataManager()
        self.wireFrame = AllowedCardListWireFrame()
    }
    
    func testShouldGoBack(){
        SDKConfiguration.sharedInstance.cards = []
        let result:Bool = self.interactor.shouldGoBack(animated: false)
        XCTAssert(!result,"The interactor should not go back without any card selected")
    }
    func testCardSelected() {
        let newCards: [CardConfiguration] = [CardConfiguration.init(withName: Constants.cardsEnum.MasterCard)]
        self.interactor.cardSelected(cards: newCards)
        XCTAssert(SDKConfiguration.sharedInstance.cards.count == newCards.count, "The count should be the same")
    }
    
}
