//
//  PreCheckoutDataInteractorTests.swift
//  MerchantCheckoutApp
//
//  Created by MasterCard on 11/07/2017.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest

@testable import MerchantCheckoutApp
class PreCheckoutDataTests: XCTestCase {

    override func setUp() {
        super.setUp()
    }
}
