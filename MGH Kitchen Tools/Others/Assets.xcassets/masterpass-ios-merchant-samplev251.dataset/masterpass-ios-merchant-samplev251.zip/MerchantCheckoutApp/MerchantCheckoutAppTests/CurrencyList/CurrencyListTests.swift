//
//  CurrencyListTests.swift
//  MerchantCheckoutAppTests
//
//  Created by MasterCard on 11/20/17.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest
@testable import MerchantCheckoutApp
class CurrencyListTests: XCTestCase {
    
    // Generating module components
    var view: CurrencyListViewProtocol!
    var presenter: CurrencyListPresenterProtocol!
    var interactor: CurrencyListInteractorInputProtocol!
    var APIDataManager: CurrencyListAPIDataManagerInputProtocol!
    var localDataManager: CurrencyListLocalDataManagerInputProtocol!
    var wireFrame: CurrencyListWireFrameProtocol!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        self.view = CurrencyListViewController.instantiate() as! CurrencyListViewProtocol
        self.presenter = CurrencyListPresenter()
        self.interactor = CurrencyListInteractor()
        self.APIDataManager = CurrencyListAPIDataManager()
        self.localDataManager = CurrencyListLocalDataManager()
        self.wireFrame = CurrencyListWireFrame()
    }
    
    func testSetCurrency(){
        let testCurrency = "USD"
        self.interactor.currencySelected(currency: testCurrency)
        
        XCTAssert(SDKConfiguration.sharedInstance.currency == testCurrency, "Currency not saved properly")
    }
    
}
