//
//  LanguageListInteractorTests.swift
//  MerchantCheckoutApp
//
//  Created by MasterCard on 10/13/2017.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest
@testable import MerchantCheckoutApp
class LanguageListTests: XCTestCase {

    var view: LanguageListViewProtocol!
    var presenter: LanguageListPresenterProtocol!
    var interactor: LanguageListInteractorInputProtocol!
    var APIDataManager: LanguageListAPIDataManagerInputProtocol!
    var localDataManager: LanguageListLocalDataManagerInputProtocol!
    var wireFrame: LanguageListWireFrameProtocol!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        self.view  = LanguageListViewController.instantiate() as! LanguageListViewProtocol
        self.presenter = LanguageListPresenter()
        self.interactor = LanguageListInteractor()
        self.APIDataManager = LanguageListAPIDataManager()
        self.localDataManager = LanguageListLocalDataManager()
        self.wireFrame = LanguageListWireFrame()
    }
    
    func testLanguageSelected(){
        self.interactor.languageSelected(language: Constants.languages.English)
        
        XCTAssert(SDKConfiguration.sharedInstance.language == Constants.languages.English, "Language not saved properly")
    }
}
