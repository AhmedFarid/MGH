//
//  OrderSummaryTests.swift
//  MerchantCheckoutAppTests
//
//  Created by MasterCard on 11/20/17.
//  Copyright © 2018 MasterCard. All rights reserved.
//

import XCTest
@testable import MerchantCheckoutApp
class OrderSummaryTests: XCTestCase {
    
    var view: OrderSummaryViewProtocol!
    var presenter: OrderSummaryPresenterProtocol!
    var interactor: OrderSummaryInteractorInputProtocol!
    var APIDataManager: OrderSummaryAPIDataManagerInputProtocol!
    var localDataManager: OrderSummaryLocalDataManagerInputProtocol!
    var wireFrame: OrderSummaryWireFrameProtocol!
    
    override func setUp() {
        super.setUp()
        self.view = OrderSummaryViewController.instantiate() as! OrderSummaryViewProtocol
        self.presenter = OrderSummaryPresenter()
        self.interactor = OrderSummaryInteractor()
        self.APIDataManager = OrderSummaryAPIDataManager()
        self.localDataManager = OrderSummaryLocalDataManager()
        self.wireFrame = OrderSummaryWireFrame()
    }
}
